import React from 'react'
import { Link } from 'react-router-dom'
export default function LaptopParts() {
  return (
    <div>
        <div className="p-16">Alaptop parts</div>
    </div>
  )
}
