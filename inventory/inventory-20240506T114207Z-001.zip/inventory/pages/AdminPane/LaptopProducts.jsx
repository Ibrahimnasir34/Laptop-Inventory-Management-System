import React from 'react'
import { Link } from 'react-router-dom'
export default function LaptopProducts() {
  return (
    <div>
        <div className="p-16">laptop products</div>
    </div>
  )
}
