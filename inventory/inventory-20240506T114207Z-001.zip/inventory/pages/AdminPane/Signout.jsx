import React from 'react'
import { Link } from 'react-router-dom'
export default function Signout() {
  return (
    <div>
        <div className="p-16">Signout</div>
    </div>
  )
}
